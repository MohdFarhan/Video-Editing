//
//  checkViewController.h
//  Stream Night Life
//
//  Created by Farhan Khan on 1/16/14.
//  Copyright (c) 2014 Smoketech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface checkViewController : UIViewController

@end
