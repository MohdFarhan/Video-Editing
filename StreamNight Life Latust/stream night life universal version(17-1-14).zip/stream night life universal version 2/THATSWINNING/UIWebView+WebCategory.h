//
//  UIWebView+WebCategory.h
//  Stream Night Life
//
//  Created by Farhan Khan on 12/16/13.
//  Copyright (c) 2013 Smoketech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (WebCategory)
-(void)removeShadows;
@end
