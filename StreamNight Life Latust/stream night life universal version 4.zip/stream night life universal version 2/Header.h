//
//  Header.h
//  Stream Night Life
//
//  Created by Vivudh Pandey on 9/16/13.
//  Copyright (c) 2013 Smoketech. All rights reserved.
//

#ifndef Stream_Night_Life_Header_h
#define Stream_Night_Life_Header_h

#define BaseUrl @"http://www.thatswinning.com/traker"

#import "AFJSONRequestOperation.h"
#import "AFHTTPClient.h"
#import "JSON.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "AFHTTPRequestOperation.h"
#import "SBJsonWriter.h"


#endif
