//
//  compDetail.h
//  THATSWINNING
//
//  Created by Mohit on 22/01/13.
//  Copyright (c) 2013 Smoketech. All rights reserved.
//

#import <UIKit/UIKit.h>

extern int pug;
extern NSMutableArray *compArray;

@interface compDetail : UIViewController
{
    IBOutlet UILabel *txtLable;
}
@end
